<footer class="footer px-5"> 
    <div class="row align-items-center justify-content-lg-between border-top">
        <div class="col-lg-6">
        <div class="copyright text-center text-lg-left">
            <strong> Sitara Chemicals © <?php echo date('Y'); ?> </strong>
        </div>
        </div>
        <div class="col-lg-6">
        <ul class="nav nav-footer justify-content-center justify-content-lg-end">
            <li class="nav-item"> 
            <a href="about-us.php" class="nav-link" target="_blank">Powered By: <strong>NTU-17-BSSE-21-P-10</strong></a>
            </li>
        </ul>
        </div>
    </div>
</footer>